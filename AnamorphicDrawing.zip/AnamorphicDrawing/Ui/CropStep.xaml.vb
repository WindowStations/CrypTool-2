﻿Imports System.Windows.Media.Imaging
Imports System.Windows.Controls
Imports System.Windows
Imports System

' Anamorphic Drawing
'
' Copyright (c) Sergey A Kryukov, 2017, 2019
'
' http://www.SAKryukov.org
' http://www.codeproject.com/Members/SAKryukov
' https://github.com/SAKryukov
'
' Original publication:
' https://www.codeproject.com/Articles/1278552/Anamorphic-Drawing-for-the-Cheaters

Namespace AnamorphicDrawing.Ui

	Partial Public Class CropStep
		Inherits UserControl
		Implements Collaboration.ICollaborationProvider

		Public Sub New()
			InitializeComponent()
			collaboration_Conflict = New Collaboration(Me, canvas, image, Nothing, AddressOf TransformImplementation)
			'collaboration_Conflict.InvokeStatusChanged(Me, New Collaboration.StatusChangeEventArgs(Collaboration.StatusChangeAspect.StatusLineMessageChange, Nothing, canvas.DataContext.ToString()))
			Dim gripSet() As CropGrip = { left, right, top, bottom }
			frameThickness = left.Width
			coupler = New CropGripCoupler(image, gripSet, cropBorder, frameThickness)
			Dim focusedGrip As CropGrip = left
			For Each grip As CropGrip In gripSet
				AddHandler grip.GotFocus, Sub(sender, eventArgs)
					focusedGrip = CType(sender, CropGrip)
					collaboration_Conflict.InvokeStatusChanged(Me, New Collaboration.StatusChangeEventArgs(Collaboration.StatusChangeAspect.SelectonChange, focusedGrip.Role.ToString(), Nothing))
				End Sub 'grip.GotFocus
			Dim firstTime As Boolean = True
			Next grip
			AddHandler collaboration_Conflict.VisibilityChanged, Sub(sender, eventArgs)
				If Visibility <> Visibility.Visible Then
					Return
				End If
				If firstTime Then
					Arrange()
				End If
				firstTime = False
				If focusedGrip IsNot Nothing Then
					focusedGrip.Focus()
				End If
			End Sub 'collaboration.VisibilityChanged
		End Sub 'CropStep

		Private Function TransformImplementation() As BitmapSource
'INSTANT VB WARNING: Instant VB cannot determine whether both operands of this division are integer types - if they are then you should use the VB integer division operator:
			Dim frameAroundImageX As Double = (canvas.ActualWidth - image.ActualWidth) / 2
'INSTANT VB WARNING: Instant VB cannot determine whether both operands of this division are integer types - if they are then you should use the VB integer division operator:
			Dim frameAroundImageY As Double = (canvas.ActualHeight - image.ActualHeight) / 2
			Dim imageLeft As Double = cropBorder.BorderThickness.Left - frameAroundImageX - frameThickness
			If imageLeft < 0 Then
				imageLeft = 0
			End If
			Dim imageRight As Double = cropBorder.BorderThickness.Right - frameAroundImageX - frameThickness
			If imageRight < 0 Then
				imageRight = 0
			End If
			Dim imageTop As Double = cropBorder.BorderThickness.Top - frameAroundImageY - frameThickness
			If imageTop < 0 Then
				imageTop = 0
			End If
			Dim imageBottom As Double = cropBorder.BorderThickness.Bottom - frameAroundImageY - frameThickness
			If imageBottom < 0 Then
				imageBottom = 0
			End If
			Dim scale As Double = collaboration_Conflict.BitmapSource.PixelWidth \ CInt(image.Width)
			imageLeft *= scale
			imageRight *= scale
			imageTop *= scale
			imageBottom *= scale
			Dim x As Integer = CInt(Math.Truncate(Math.Round(imageLeft)))
			Dim y As Integer = CInt(Math.Truncate(Math.Round(imageTop)))
'INSTANT VB NOTE: The variable width was renamed since Visual Basic does not handle local variables named the same as class members well:
			Dim width_Conflict As Integer = CInt(collaboration_Conflict.BitmapSource.PixelWidth) - x - CInt(Math.Truncate(Math.Round(imageRight)))
'INSTANT VB NOTE: The variable height was renamed since Visual Basic does not handle local variables named the same as class members well:
			Dim height_Conflict As Integer = CInt(collaboration_Conflict.BitmapSource.PixelHeight) - y - CInt(Math.Truncate(Math.Round(imageBottom)))
			Return New CroppedBitmap(collaboration_Conflict.BitmapSource, New Int32Rect(x, y, width_Conflict, height_Conflict))
		End Function 'TransformImplementation

		Private Overloads Sub Arrange()
			If Visibility <> Visibility.Visible Then
				Return
			End If
			Main.ImageProcessingUtility.ArrangeImage(collaboration_Conflict.BitmapSource, image, canvas)
			coupler.Arrange()
		End Sub 'Arrange

		Protected Overrides Sub OnRenderSizeChanged(ByVal sizeInfo As SizeChangedInfo)
			Arrange()
		End Sub

'INSTANT VB NOTE: The field collaboration was renamed since Visual Basic does not allow fields to have the same name as other class members:
		Private collaboration_Conflict As Collaboration
		Private ReadOnly Property ICollaborationProvider_Collaboration() As Collaboration Implements Collaboration.ICollaborationProvider.Collaboration
			Get
				Return collaboration_Conflict
			End Get
		End Property
		Private coupler As CropGripCoupler
		Private frameThickness As Double
		Private firstTime As Boolean
	End Class 'class CropStep

End Namespace 'namespace AnamorphicDrawing.Ui
