﻿Imports System.Windows.Media.Imaging
Imports System.Windows.Input
Imports System.Windows

' Anamorphic Drawing
'
' Copyright (c) Sergey A Kryukov, 2017, 2019
'
' http://www.SAKryukov.org
' http://www.codeproject.com/Members/SAKryukov
' https://github.com/SAKryukov
'
' Original publication:
' https://www.codeproject.com/Articles/1278552/Anamorphic-Drawing-for-the-Cheaters

Namespace AnamorphicDrawing.Ui

	Partial Public Class MainWindow
		Inherits Window

		Private NotInheritable Class DefinitionSet

			Private Sub New()
			End Sub

			Friend Const openDialogFilter As String = "Image files|*.tif;*.tiff;*.jpg;*.jpeg;*.png;*.bmp;*.gif"
			Friend Const saveDialogFilter As String = "PNG files|*.png"
			Friend Const openDialogTitle As String = " Open Source Image"
			Friend Const saveDialogTitle As String = " Save Anamorphic Image"
		End Class 'class DefinitionSet
		Friend Sub Foo()
			If isDirty AndAlso Not ClosingOpeningHandler(True) Then
				Return
			End If
			If Not OpenDialog.ShowDialog().Equals(True) Then
				Return
			End If
			pages(currentPageIndex).Collaboration.BitmapSource = New BitmapImage(New System.Uri(OpenDialog.FileName, System.UriKind.RelativeOrAbsolute))
			SetApplicationTitle(OpenDialog.FileName)
		End Sub
		Friend Sub Faa()

			'EventArgs.CanExecute = currentPageIndex = 0

		End Sub
		Friend Sub Meclose()
			Close()
		End Sub
		Friend Sub ShowTangi()
			'TangibleLambdaToken29about.ShowDialog()
		End Sub
		Public Sub New()
			InitializeComponent()
			OpenDialog.Title = DefinitionSet.openDialogTitle
			SaveDialog.Title = DefinitionSet.saveDialogTitle
			OpenDialog.Filter = DefinitionSet.openDialogFilter
			SaveDialog.Filter = DefinitionSet.saveDialogFilter
			pages = New Collaboration.ICollaborationProvider() { Me.stepFirst, Me.stepCrop, Me.stepFinish }
			finalPage = Me.stepFinish
			For Each page In pages
				AddHandler page.Collaboration.StatusChanged, Sub(sender, eventArgs)
					If (eventArgs.Aspect And Collaboration.StatusChangeAspect.SelectonChange) > 0 AndAlso eventArgs.SelectionInfo IsNot Nothing Then
						Me.selectionInfo.Content = eventArgs.SelectionInfo
					End If
					If (eventArgs.Aspect And Collaboration.StatusChangeAspect.StatusLineMessageChange) > 0 AndAlso eventArgs.StatusMessage IsNot Nothing Then
						Me.statusMessage.Content = eventArgs.StatusMessage
					End If
				End Sub 'page.Collaboration.StatusChanged
				'AddHandler miHelpAbout.Click, Sub(sender, eventArgs) TangibleLambdaToken29about.ShowDialog()
			Next page 'miHelpAbout.Click
			AddHandler miQuit.Click, AddressOf Meclose
			''???
			''Me.CommandBindings.Add(New CommandBinding(ApplicationCommands.Open, New ExecutedRoutedEventHandler(AddressOf Foo, New CanExecuteRoutedEventHandler(AddressOf Faa))) 'OpenMe.CommandBindings.Add(New CommandBinding(ApplicationCommands.Save, New ExecutedRoutedEventHandler(Sub(sender, eventArgs)
			'Save()
			'End Sub), New CanExecuteRoutedEventHandler(Sub(sender, eventArgs)
			'	eventArgs.CanExecute = currentPageIndex > 0
			'End Sub))); 'SaveMe.CommandBindings.Add(New CommandBinding(ApplicationCommands.Help, New ExecutedRoutedEventHandler(Sub(sender, eventArgs)
			'	If help_Conflict Is Nothing Then
			'		help_Conflict = New Help()
			'		help_Conflict.ShowActivated = True
			'		AddHandler help_Conflict.Closing, Sub(helpSender, helpEventArgs)
			'			helpEventArgs.Cancel = True
			'			help_Conflict.Hide()
			'		End Sub
			'	End If
			'	help_Conflict.WizardStep = pages(currentPageIndex).Collaboration.WizardStep
			'	help_Conflict.Show()
			'	help_Conflict.Activate()
			'End Sub))); 'HelpMe.CommandBindings.Add(New CommandBinding(ApplicationCommands.Print, New ExecutedRoutedEventHandler(Sub(sender, eventArgs)
			'	Main.ImageProcessingUtility.PrintImage(pages(currentPageIndex).Collaboration.BitmapSource)
			'End Sub), New CanExecuteRoutedEventHandler(Sub(sender, eventArgs)
			'	eventArgs.CanExecute = currentPageIndex > 0
			'End Sub))); 'PrintMe.CommandBindings.Add(New CommandBinding(ApplicationCommands.Undo, New ExecutedRoutedEventHandler(Sub(sender, eventArgs)
			'	pages(currentPageIndex).Collaboration.Visibility = System.Windows.Visibility.Hidden
			'	currentPageIndex -= 1
			'	pages(currentPageIndex).Collaboration.Visibility = System.Windows.Visibility.Visible
			'End Sub), New CanExecuteRoutedEventHandler(Sub(sender, eventArgs)
			'	eventArgs.CanExecute = currentPageIndex <> 0
			'End Sub))); 'UndoMe.CommandBindings.Add(New CommandBinding(ApplicationCommands.Redo, New ExecutedRoutedEventHandler(Sub(sender, eventArgs)
			'	Dim transformedBitmap As BitmapSource = pages(currentPageIndex).Collaboration.Transform()
			'	If transformedBitmap Is Nothing Then
			'		Return
			'	End If
			'	pages(currentPageIndex).Collaboration.Visibility = System.Windows.Visibility.Hidden
			'	currentPageIndex += 1
			'	If currentPageIndex < pages.Length Then
			'		pages(currentPageIndex).Collaboration.BitmapSource = transformedBitmap
			'	End If
			'	pages(currentPageIndex).Collaboration.Visibility = System.Windows.Visibility.Visible
			'	If pages(currentPageIndex) Is finalPage Then
			'		isFinalStepDirty = True
			'	End If
			'End Sub), New CanExecuteRoutedEventHandler(Sub(sender, eventArgs)
			'	eventArgs.CanExecute = (currentPageIndex < pages.Length - 1) AndAlso pages(currentPageIndex).Collaboration.IsReadyForNext
			'End Sub))); 'Redo}protected override void OnContentRendered(System.EventArgs e){' to prevent status bar separator jerking back and forth:Me.selectionInfo.Width = Me.selectionInfo.ActualWidth
			'ProcessCommandLine()
		End Sub 'protected override void OnContentRendered(System.EventArgs e)

		Protected Overrides Sub OnClosing(ByVal e As System.ComponentModel.CancelEventArgs)
			e.Cancel = Not ClosingOpeningHandler(False)
		End Sub 'OnClosing

		Private Sub ProcessCommandLine()
			Dim args = Environment.GetCommandLineArgs()
			If args.Length < 2 Then
				Return
			End If
			Dim fileName As String = args(1)
			If Not System.IO.File.Exists(fileName) Then
				Return
			End If
			pages(0).Collaboration.BitmapSource = New BitmapImage(New System.Uri(fileName, System.UriKind.RelativeOrAbsolute))
			SetApplicationTitle(fileName)
		End Sub 'ProcessCommandLine

		Private Sub SetApplicationTitle(ByVal fileName As String)
			Title = String.Format(AnamorphicDrawing.Resources.Application.TitleFormatMainWithFileName, System.IO.Path.GetFileName(fileName), Main.AnamorphicDrawingApplication.Current.ProductName)
		End Sub 'SetApplicationTitle

		Private Function Save(ByVal page As Collaboration.ICollaborationProvider) As Boolean
			If page.Collaboration.BitmapSource Is Nothing Then
				Return False
			End If
			If SaveDialog.ShowDialog().Equals(True) Then
				Main.ImageProcessingUtility.SaveBitmap(page.Collaboration.BitmapSource, SaveDialog.FileName)
			Else
				Return False
			End If
			If page Is finalPage Then
				isFinalStepDirty = False
			End If
			Return True
		End Function 'Save
		Private Function Save() As Boolean
			Return Save(pages(currentPageIndex))
		End Function 'Save

		Private Function ClosingOpeningHandler(ByVal isOpening As Boolean) As Boolean
			If isDirty Then
				Dim buttons As MessageBoxButton = MessageBoxButton.YesNoCancel
				Dim question As String = AnamorphicDrawing.Resources.Application.WarningUnsavedWork
				If isOpening Then
					 question = AnamorphicDrawing.Resources.Application.WarningUnsavedWorkOpen
				End If
				Dim suggestion As String = AnamorphicDrawing.Resources.Application.RecommendationToSaveIntermediate
				If currentPageIndex = 1 Then
					suggestion = AnamorphicDrawing.Resources.Application.RecommendationToSaveIntermediateCropStep
				End If
				question &= Environment.NewLine & AnamorphicDrawing.Resources.Application.RecommendationToSave & Environment.NewLine & Environment.NewLine & suggestion
				Dim result = MessageBox.Show(question, String.Format(AnamorphicDrawing.Resources.Application.TitleFormatMain, Main.AnamorphicDrawingApplication.Current.ProductName), buttons, MessageBoxImage.Question, MessageBoxResult.Cancel)
				If result = MessageBoxResult.Cancel Then
					Return False
				End If
				If result = MessageBoxResult.Yes Then
					If Not Save(finalPage) Then
						Return False
					End If
				End If
			End If 'if
			Return True
		End Function 'ClosingHandler

		Private pages() As Collaboration.ICollaborationProvider
		Private finalPage As Collaboration.ICollaborationProvider
		Private currentPageIndex As Integer = 0

		Private ReadOnly Property isDirty() As Boolean
			Get
				Return isFinalStepDirty AndAlso Me.finalPage.Collaboration.BitmapSource IsNot Nothing
			End Get
		End Property
		Private isFinalStepDirty As Boolean
		Private OpenDialog As New Microsoft.Win32.OpenFileDialog()
		Private SaveDialog As New Microsoft.Win32.SaveFileDialog()
'INSTANT VB NOTE: The variable about was renamed since it may cause conflicts with calls to static members of the user-defined type with this name:
		Private about_Conflict As About
'INSTANT VB NOTE: The variable help was renamed since it may cause conflicts with calls to static members of the user-defined type with this name:
		Private help_Conflict As Help

	End Class 'class MainWindow

End Namespace 'namespace AnamorphicDrawing.Ui
