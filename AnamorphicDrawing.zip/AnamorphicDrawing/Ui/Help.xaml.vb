﻿Imports System.Reflection
Imports System.IO
Imports System.Windows
Imports System

' Anamorphic Drawing
'
' Copyright (c) Sergey A Kryukov, 2017, 2019
'
' http://www.SAKryukov.org
' http://www.codeproject.com/Members/SAKryukov
' https://github.com/SAKryukov
'
' Original publication:
' https://www.codeproject.com/Articles/1278552/Anamorphic-Drawing-for-the-Cheaters

Namespace AnamorphicDrawing.Ui

	Partial Public Class Help
		Inherits Window

		Friend Class HelpException
			Inherits System.ApplicationException

			Friend Sub New(ByVal filePattern As String, ByVal directory As String)
				MyBase.New(String.Format(AnamorphicDrawing.Resources.Exceptions.HelpExceptionFileNotFound, filePattern, directory))
			End Sub
			Friend Sub New(ByVal filePattern As String, ByVal directory As String, ByVal filesFound As Integer)
				MyBase.New(String.Format(AnamorphicDrawing.Resources.Exceptions.HelpExceptionTooManyFilesNotFound, filePattern, directory, filesFound))
			End Sub
		End Class 'class HelpException

		Friend Sub New()
			InitializeComponent()
			Dim productName As String = Main.AnamorphicDrawingApplication.Current.ProductName
			Title = String.Format(AnamorphicDrawing.Resources.Application.TitleFormatHelp, productName)
			Dim updateStatus As Action = Sub()
				buttonBack.IsEnabled = browser.CanGoBack
				buttonForward.IsEnabled = browser.CanGoForward
				buttonHome.IsEnabled = browser.Source IsNot Nothing
			End Sub 'updateStatus
			Dim path As String = System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetEntryAssembly().Location)
			Dim filePattern As String = AnamorphicDrawing.Resources.Application.HelpFilePattern
			Dim files() As String = Directory.GetFiles(path, filePattern, SearchOption.AllDirectories)
			If files.Length < 1 Then
				Throw New HelpException(filePattern, path)
			ElseIf files.Length <> 1 Then
				Throw New HelpException(filePattern, path, files.Length)
			End If
			helpFile = files(0)
			AddHandler buttonHome.Click, Sub(sender, eventArgs)
				browser.Navigate(New Uri(helpFile, UriKind.RelativeOrAbsolute))
			End Sub 'buttonHome.Click
			AddHandler buttonBack.Click, Sub(sender, eventArgs)
				If browser.CanGoBack Then
					browser.GoBack()
				End If
				updateStatus()
			End Sub 'buttonBack.Click
			AddHandler browser.LoadCompleted, Sub(sender, eventArgs)
				Me.status.Content = AnamorphicDrawing.Resources.Application.HelpStatusLoaded
				If browser.Source IsNot Nothing AndAlso browser.Source.Scheme <> System.Uri.UriSchemeFile Then
					Me.Uri.Text = browser.Source.ToString()
				Else
					Me.Uri.Text = productName
				End If
				updateStatus()
			End Sub 'browser.LoadCompleted
			AddHandler buttonForward.Click, Sub(sender, eventArgs)
				If browser.CanGoForward Then
					browser.GoForward()
				End If
				updateStatus()
			End Sub 'buttonForward.Click
			AddHandler browser.Navigating, Sub(sender, eventArgs)
				Me.status.Content = AnamorphicDrawing.Resources.Application.HelpStatusLoading
				updateStatus()
			End Sub 'browser.Navigating
			browser.Focus()
		End Sub 'Help

		Friend WriteOnly Property WizardStep() As String
			Set(ByVal value As String)
				Dim ub As New UriBuilder(helpFile)
				ub.Fragment = value
				browser.Navigate(ub.Uri)
			End Set 'set WizardStep
		End Property 'WizardStep

		Private helpFile As String

	End Class 'namespace AnamorphicDrawing.Ui

End Namespace 'namespace AnamorphicDrawing.Ui
