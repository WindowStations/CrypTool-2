﻿Imports DispatcherPriority = System.Windows.Threading.DispatcherPriority
Imports System.Windows.Media.Imaging
Imports System.Windows.Controls
Imports System.Windows
Imports System

' Anamorphic Drawing
'
' Copyright (c) Sergey A Kryukov, 2017, 2019
'
' http://www.SAKryukov.org
' http://www.codeproject.com/Members/SAKryukov
' https://github.com/SAKryukov
'
' Original publication:
' https://www.codeproject.com/Articles/1278552/Anamorphic-Drawing-for-the-Cheaters

Namespace AnamorphicDrawing.Ui

	Partial Public Class FirstStep
		Inherits UserControl
		Implements Collaboration.ICollaborationProvider

		Public Sub New()
			InitializeComponent()
			collaboration_Conflict = New Collaboration(Me, canvas, image, AddressOf CanGoNextImplementation, AddressOf TransformImplementation)
			Dim gripSet() As LocationGrip = { topLeft, topRight, bottomRight, bottomLeft }
			locationGripCoupler = New LocationGripCoupler(image, gripSet, pad, mark)
			Dim focusedGrip As LocationGrip = Nothing
			AddHandler collaboration_Conflict.VisibilityChanged, Sub(sender, eventArgs)
				If Visibility <> Visibility.Visible Then
					Return
				End If
				If focusedGrip IsNot Nothing Then
					focusedGrip.Focus()
				End If
			End Sub 'collaboration.VisibilityChanged
			For Each grip In gripSet
				AddHandler grip.GotFocus, Sub(sender, eventArgs)
					focusedGrip = CType(sender, LocationGrip)
					collaboration_Conflict.InvokeStatusChanged(Me, New Collaboration.StatusChangeEventArgs(Collaboration.StatusChangeAspect.SelectonChange, focusedGrip.DataContext.ToString(), Nothing))
				End Sub
				AddHandler grip.LocationChanged, Sub(sender, eventArgs)
					Me.validGripPositions = АreValidGripPositions()
					If Me.validGripPositions Then
						collaboration_Conflict.InvokeStatusChanged(Me, New Collaboration.StatusChangeEventArgs(Collaboration.StatusChangeAspect.NextEnabledChange Or Collaboration.StatusChangeAspect.StatusLineMessageChange, Nothing, permanentStatusMessage))
					Else
						collaboration_Conflict.InvokeStatusChanged(Me, New Collaboration.StatusChangeEventArgs(Collaboration.StatusChangeAspect.NextEnabledChange Or Collaboration.StatusChangeAspect.StatusLineMessageChange, Nothing, invalidStatusMessage))
					End If
				End Sub 'grip.LocationChanged
			Next grip 'loop
			'permanentStatusMessage = canvas.DataContext.ToString()
			'invalidStatusMessage = image.DataContext.ToString()
		End Sub 'FirstStep

		Private alreadyRendered As Boolean
		Protected Overrides Sub OnRender(ByVal drawingContext As System.Windows.Media.DrawingContext)
			MyBase.OnRender(drawingContext)
			Dispatcher.BeginInvoke(New System.Action(Sub()
				collaboration_Conflict.InvokeStatusChanged(Me, New Collaboration.StatusChangeEventArgs(Collaboration.StatusChangeAspect.StatusLineMessageChange, Nothing, permanentStatusMessage))
			End Sub))
			If Not alreadyRendered Then
				Dispatcher.BeginInvoke(New System.Action(Sub()
					bottomRight.Focus()
				End Sub))
				Dispatcher.BeginInvoke(DispatcherPriority.ApplicationIdle, New System.Action(Sub()
					topLeft.Focus()
				End Sub))
			End If 'alreadyRendered
			alreadyRendered = True
		End Sub 'OnRender

		Protected Overrides Sub OnRenderSizeChanged(ByVal sizeInfo As SizeChangedInfo)
			Main.ImageProcessingUtility.ArrangeImage(collaboration_Conflict.BitmapSource, image, canvas)
'INSTANT VB WARNING: Instant VB cannot determine whether both operands of this division are integer types - if they are then you should use the VB integer division operator:
			locationGripCoupler.Arrange(New Point(bottomLeft.ActualWidth/2, bottomLeft.ActualHeight/2), New Size(canvas.ActualWidth, canvas.ActualHeight))
		End Sub 'protected override void OnRenderSizeChanged(SizeChangedInfo sizeInfo)

		Private Function TransformImplementation() As BitmapSource
			Return Main.ImageProcessingUtility.PerspectiveTransformFromRelativePoints(collaboration_Conflict.BitmapSource, topLeft.Location, topRight.Location, bottomRight.Location, bottomLeft.Location, image.Width)
		End Function 'TransformImplementation
		Private Function CanGoNextImplementation() As Boolean
			Return validGripPositions
		End Function

		Private Function АreValidGripPositions() As Boolean
			If collaboration_Conflict.BitmapSource Is Nothing Then
				Return True
			End If
			Dim bitmapPixelWidth As Integer = collaboration_Conflict.BitmapSource.PixelWidth
			Dim bitmapPixelHeight As Integer = collaboration_Conflict.BitmapSource.PixelHeight
'INSTANT VB WARNING: Instant VB cannot determine whether both operands of this division are integer types - if they are then you should use the VB integer division operator:
			Dim factorSet As New Main.ImageProcessingUtility.MarkFactorSet(topLeft.Location, topRight.Location, bottomRight.Location, bottomLeft.Location, bitmapPixelHeight, CDbl(bitmapPixelWidth) / CDbl(bitmapPixelHeight), bitmapPixelWidth / image.ActualWidth)
			Return factorSet.IsValid
		End Function 'АreValidGripPositions

		Private ReadOnly Property ICollaborationProvider_Collaboration() As Collaboration Implements Collaboration.ICollaborationProvider.Collaboration
			Get
				Return collaboration_Conflict
			End Get
		End Property

		Private locationGripCoupler As LocationGripCoupler
'INSTANT VB NOTE: The field collaboration was renamed since Visual Basic does not allow fields to have the same name as other class members:
		Private collaboration_Conflict As Collaboration
		Private validGripPositions As Boolean = True
		Private permanentStatusMessage, invalidStatusMessage As String

	End Class 'class FirstStep

End Namespace 'namespace AnamorphicDrawing.Ui
