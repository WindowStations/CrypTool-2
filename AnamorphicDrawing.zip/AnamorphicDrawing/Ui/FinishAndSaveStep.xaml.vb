﻿Imports System.Windows.Controls
Imports System.Windows

' Anamorphic Drawing
'
' Copyright (c) Sergey A Kryukov, 2017, 2019
'
' http://www.SAKryukov.org
' http://www.codeproject.com/Members/SAKryukov
' https://github.com/SAKryukov
'
' Original publication:
' https://www.codeproject.com/Articles/1278552/Anamorphic-Drawing-for-the-Cheaters

Namespace AnamorphicDrawing.Ui

	Partial Public Class FinishAndSaveStep
		Inherits UserControl
		Implements Collaboration.ICollaborationProvider

		Public Sub New()
			InitializeComponent()
			collaboration_Conflict = New Collaboration(Me, canvas, image, Nothing, Nothing)
			'collaboration_Conflict.InvokeStatusChanged(Me, New Collaboration.StatusChangeEventArgs(Collaboration.StatusChangeAspect.StatusLineMessageChange Or Collaboration.StatusChangeAspect.SelectonChange, image.DataContext.ToString(), canvas.DataContext.ToString()))
		End Sub 'FinishAndSaveStep

		Protected Overrides Sub OnRenderSizeChanged(ByVal sizeInfo As SizeChangedInfo)
			Main.ImageProcessingUtility.ArrangeImage(collaboration_Conflict.BitmapSource, image, canvas)
		End Sub 'OnRenderSizeChanged

'INSTANT VB NOTE: The field collaboration was renamed since Visual Basic does not allow fields to have the same name as other class members:
		Private collaboration_Conflict As Collaboration
		Private ReadOnly Property ICollaborationProvider_Collaboration() As Collaboration Implements Collaboration.ICollaborationProvider.Collaboration
			Get
				Return collaboration_Conflict
			End Get
		End Property

	End Class 'class FinishAndSaveStep

End Namespace 'namespace AnamorphicDrawing.Ui
