﻿Imports System.Windows

' Anamorphic Drawing
'
' Copyright (c) Sergey A Kryukov, 2017, 2019
'
' http://www.SAKryukov.org
' http://www.codeproject.com/Members/SAKryukov
' https://github.com/SAKryukov
'
' Original publication:
' https://www.codeproject.com/Articles/1278552/Anamorphic-Drawing-for-the-Cheaters

Namespace AnamorphicDrawing.Ui

	Partial Public Class About
		Inherits Window

		Friend Sub New()
			InitializeComponent()
'INSTANT VB NOTE: The variable application was renamed since it may cause conflicts with calls to static members of the user-defined type with this name:
			Dim application_Conflict As Main.AnamorphicDrawingApplication = Main.AnamorphicDrawingApplication.Current
			Title = String.Format(AnamorphicDrawing.Resources.Application.TitleFormatAbout, application_Conflict.ProductName)
			Dim version = application_Conflict.AssemblyVersion
			Me.textBlockProduct.Text = String.Format(AnamorphicDrawing.Resources.Application.VersionFormat, application_Conflict.ProductName, version.Major, version.Minor)
			Me.texBlockCopyright.Text = Main.AnamorphicDrawingApplication.Current.Copyright
			AddHandler buttonOk.Click, Sub(sender, eventArgs)
				Hide()
			End Sub
			buttonOk.Focus()
		End Sub 'About

	End Class 'class About

End Namespace 'namespace AnamorphicDrawing.Ui
