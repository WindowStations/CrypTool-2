﻿Imports DrawingVisual = System.Windows.Media.DrawingVisual
Imports PrintDialog = System.Windows.Controls.PrintDialog
Imports System.Windows.Controls
Imports System.Windows.Media.Imaging
Imports System.Windows.Media
Imports System.Windows
Imports System.IO

' Anamorphic Drawing
'
' Copyright (c) Sergey A Kryukov, 2017, 2019
'
' http://www.SAKryukov.org
' http://www.codeproject.com/Members/SAKryukov
' https://github.com/SAKryukov
'
' Original publication:
' https://www.codeproject.com/Articles/1278552/Anamorphic-Drawing-for-the-Cheaters

Namespace AnamorphicDrawing.Main

	Friend Module ImageProcessingUtility

		Private Const fundamentallyLowSize As Double = 2

		Friend Sub SaveBitmap(ByVal source As BitmapSource, ByVal fileName As String)
			Using fs As New FileStream(fileName, FileMode.Create)
				Dim encoder As New PngBitmapEncoder()
				encoder.Frames.Add(BitmapFrame.Create(source))
				encoder.Save(fs)
			End Using 'using
		End Sub 'saveBitmap

		Friend Sub ArrangeImage(ByVal bitmap As BitmapSource, ByVal image As Image, ByVal canvas As Canvas)
			If bitmap Is Nothing Then
				Return
			End If
			Dim imageAspect As Double = CDbl(bitmap.Width) / CDbl(bitmap.Height)
			Dim parentAspect As Double = CDbl(canvas.ActualWidth) / CDbl(canvas.ActualHeight)
			If imageAspect > parentAspect Then
				image.Width = canvas.ActualWidth
				image.Height = image.Width / imageAspect
				System.Windows.Controls.Canvas.SetLeft(image, 0)
				System.Windows.Controls.Canvas.SetTop(image, (canvas.ActualHeight - image.Height) / 2)
			Else
				image.Height = canvas.ActualHeight
				image.Width = image.Height * imageAspect
				System.Windows.Controls.Canvas.SetTop(image, 0)
				System.Windows.Controls.Canvas.SetLeft(image, (canvas.ActualWidth - image.Width) / 2)
			End If 'if
		End Sub 'ArrangeImage

		Friend Sub PrintImage(ByVal imageSource As BitmapSource)
			If imageSource Is Nothing Then
				Return
			End If
			If imageSource.PixelWidth < 1 OrElse imageSource.PixelHeight < 1 Then
				Return
			End If
			Dim printDialog = New PrintDialog()
			If Not printDialog.ShowDialog().Equals(True) Then
				Return
			End If
			Dim printableWidth As Double = printDialog.PrintableAreaWidth
			Dim printableHeight As Double = printDialog.PrintableAreaHeight
			Dim imageAspect As Double = imageSource.PixelWidth \ imageSource.PixelHeight
			Dim printAspect As Double = printableWidth / printableHeight
			If (imageAspect > 1 AndAlso printAspect < 1) OrElse (imageAspect < 1 AndAlso printAspect > 1) Then
				imageSource = New TransformedBitmap(imageSource, New RotateTransform(90))
				imageAspect = 1 / imageAspect
			End If 'if
			Dim x0, y0, width, height As Double
			If imageAspect > printAspect Then
				width = printableWidth
				height = width / imageAspect
				x0 = 0
				y0 = (printableHeight - height) / 2
			Else
				height = printableHeight
				width = height * imageAspect
				y0 = 0
				x0 = (printableWidth - width) / 2
			End If 'if
			Dim drawingVisual = New DrawingVisual()
			Dim dc = drawingVisual.RenderOpen()
			Try
				dc.DrawImage(imageSource, New Rect(x0, y0, width, height))
			Finally
				dc.Close()
			End Try
			printDialog.PrintVisual(drawingVisual, Nothing)
		End Sub 'PrintImage

		Friend Class MarkFactorSet
			Private Delegate Sub SwapMethod(ByRef smaller As Double, ByRef greater As Double)
			Friend Sub New()
				IsValid = False
			End Sub
			Friend Sub New(ByVal topLeft As Point, ByVal topRight As Point, ByVal bottomRight As Point, ByVal bottomLeft As Point, ByVal bitmapPixelHeight As Integer, ByVal bitmapAspect As Double, ByVal scale As Double)
				Dim swap As SwapMethod = Sub(ByRef smaller As Double, ByRef greater As Double)
					If smaller > greater Then
						Dim temp As Double = smaller
						smaller = greater
						greater = temp
					End If 'if
				End Sub 'swap
				Me.LongSide = bottomRight.X - bottomLeft.X
				If LongSide < 0 Then
					LongSide = -LongSide
				End If
				Me.ShortSide = topRight.X - topLeft.X
				If ShortSide < 0 Then
					ShortSide = -ShortSide
				End If
				swap(ShortSide, LongSide)
				Me.LowerY = (bottomLeft.Y + bottomRight.Y) / 2
				Me.UpperY = (topLeft.Y + topRight.Y) / 2
				swap(UpperY, LowerY) ' lowerY should be greater the upperY
				Me.Height = LowerY - UpperY
				IsValid = Height > fundamentallyLowSize AndAlso ShortSide > fundamentallyLowSize AndAlso LongSide > fundamentallyLowSize 'SA???
				If Not IsValid Then
					Return
				End If
				Me.Scale(scale)
				Dim denominator As Double = ShortSide * LowerY - LongSide * UpperY
				Dim markWidth As Double = bitmapAspect * Height
				Dim factor As Double = (markWidth / ShortSide - markWidth / LongSide) / (UpperY - LowerY)
				HorizontalScaleFrom = markWidth / ShortSide - factor * UpperY
				HorizontalScaleTo = HorizontalScaleFrom + factor * bitmapPixelHeight
				IsValid = HorizontalScaleFrom > 0 AndAlso HorizontalScaleTo > 0
			End Sub 'MarkFactoSet
			Private Sub Scale(ByVal factor As Double)
				LongSide *= factor
				ShortSide *= factor
				UpperY *= factor
				LowerY *= factor
				Height *= factor
			End Sub 'Scale
			Private privateIsValid As Boolean
			Friend Property IsValid() As Boolean
				Get
					Return privateIsValid
				End Get
				Private Set(ByVal value As Boolean)
					privateIsValid = value
				End Set
			End Property
			Friend LongSide As Double
			Friend ShortSide As Double
			Friend UpperY As Double
			Friend LowerY As Double
			Friend Height As Double
			Friend HorizontalScaleFrom As Double
			Friend HorizontalScaleTo As Double
		End Class 'class MarkFactoSet

		Friend Function PerspectiveTransformFromRelativePoints(ByVal bitmap As BitmapSource, ByVal topLeft As Point, ByVal topRight As Point, ByVal bottomRight As Point, ByVal bottomLeft As Point, ByVal imageWidth As Double) As BitmapSource
			Dim bitmapAspect As Double = CDbl(bitmap.PixelWidth) / CDbl(bitmap.PixelHeight)
			Dim factorSet As New MarkFactorSet(topLeft, topRight, bottomRight, bottomLeft, bitmap.PixelHeight, bitmapAspect, bitmap.PixelWidth / imageWidth)
			If Not factorSet.IsValid Then
				Return Nothing
			End If
			Return (New PerspectiveTransform(factorSet.HorizontalScaleFrom, factorSet.HorizontalScaleTo)).Apply(bitmap)
		End Function 'PerspectiveTransformFromRelativePoints

	End Module 'class ImageProcessingUtility

End Namespace 'namespace AnamorphicDrawing.Main
