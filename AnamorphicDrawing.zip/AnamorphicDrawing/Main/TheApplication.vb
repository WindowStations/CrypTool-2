﻿Imports StringBuilder = System.Text.StringBuilder
Imports StringList = System.Collections.Generic.List(Of String)
Imports System.Reflection
Imports System.Windows
Imports System

' Anamorphic Drawing
'
' Copyright (c) Sergey A Kryukov, 2017, 2019
'
' http://www.SAKryukov.org
' http://www.codeproject.com/Members/SAKryukov
' https://github.com/SAKryukov
'
' Original publication:
' https://www.codeproject.com/Articles/1278552/Anamorphic-Drawing-for-the-Cheaters

Namespace AnamorphicDrawing.Main
'INSTANT VB NOTE: VB does not allow aliasing interfaces:
'	using IStringList = System.Collections.Generic.IList(Of string)

	Friend Class AnamorphicDrawingApplication
		Inherits Application

		Friend Sub New()
			AddHandler Me.DispatcherUnhandledException, Sub(sender, eventArgs)
				ShowException(eventArgs.Exception)
				eventArgs.Handled = True
			End Sub 'DispatcherUnhandledException
		End Sub 'AnamorphicDrawingApplication

		Protected Overrides Sub OnStartup(ByVal e As StartupEventArgs)
			Me.ShutdownMode = ShutdownMode.OnMainWindowClose
			MainWindow = New Ui.MainWindow()
			MainWindow.Title = String.Format(AnamorphicDrawing.Resources.Application.TitleFormatMain, ProductName)
			MainWindow.Show()
			startupComplete = True
		End Sub 'OnStartup

		Private Sub ShowException(ByVal e As Exception)
			Dim exceptionTextFinder As Func(Of Exception, String) = Function(ex)
				Dim exceptionTextCollector As Action(Of Exception, System.Collections.Generic.IList(Of String)) = Nothing ' for recursiveness
				exceptionTextCollector = Sub(exc, aList)
											 'aList.Add(String.Format(AnamorphicDrawing.Resources.Exceptions.ExceptionFormat, exc.GetType().FullName, exc.Message))
											 If exc.InnerException IsNot Nothing Then
						exceptionTextCollector(exc.InnerException, aList)
					End If
				End Sub 'exceptionTextCollector
				Dim list As System.Collections.Generic.IList(Of String) = New StringList()
				exceptionTextCollector(ex, list)
				Dim sb As New StringBuilder()
				Dim first As Boolean = True
				For Each item As String In list
					If first Then
						sb.Append(item)
						first = False
					Else
						sb.Append(AnamorphicDrawing.Resources.Exceptions.ExceptionStackItemDemiliter & item)
					End If
				Next item
				Return sb.ToString()
			End Function 'exceptionTextFinder
			MessageBox.Show(exceptionTextFinder(e), ProductName, MessageBoxButton.OK, MessageBoxImage.Error)
			If Not startupComplete Then
				Shutdown()
			End If
		End Sub 'ShowException

		<STAThread>
		Shared Sub Main(ByVal args() As String)
			Dim app As Application = New AnamorphicDrawingApplication()
			app.Run()
		End Sub 'Main

		Friend ReadOnly Property ProductName() As String
			Get
				If productName_Conflict Is Nothing Then
					Dim attributes() As Object = TheAssembly.GetCustomAttributes(GetType(AssemblyProductAttribute), False)
					If attributes Is Nothing Then
						Return Nothing
					End If
					If attributes.Length < 1 Then
						Return Nothing
					End If
					productName_Conflict = DirectCast(attributes(0), AssemblyProductAttribute).Product
				End If 'if
				Return productName_Conflict
			End Get 'get ProductName
		End Property 'ProductName
		Friend ReadOnly Property Copyright() As String
			Get
				If copyright_Conflict Is Nothing Then
					Dim attributes() As Object = TheAssembly.GetCustomAttributes(GetType(AssemblyCopyrightAttribute), False)
					If attributes Is Nothing Then
						Return Nothing
					End If
					If attributes.Length < 1 Then
						Return Nothing
					End If
					copyright_Conflict = DirectCast(attributes(0), AssemblyCopyrightAttribute).Copyright
				End If 'if
				Return copyright_Conflict
			End Get 'get Copyright
		End Property 'Copyright
		Friend ReadOnly Property AssemblyVersion() As Version
			Get
				If assemblyVersion_Conflict Is Nothing Then
					Dim attributes() As Object = TheAssembly.GetCustomAttributes(GetType(AssemblyFileVersionAttribute), False)
					If attributes Is Nothing Then
						Return Nothing
					End If
					If attributes.Length < 1 Then
						Return Nothing
					End If
					assemblyVersion_Conflict = New Version(DirectCast(attributes(0), AssemblyFileVersionAttribute).Version)
				End If 'if
				Return assemblyVersion_Conflict
			End Get 'get AssemblyVersion
		End Property 'AssemblyVersion
		Friend ReadOnly Property AssemblyInformationalVersion() As Version
			Get
				If assemblyVersion_Conflict Is Nothing Then
					Dim attributes() As Object = TheAssembly.GetCustomAttributes(GetType(AssemblyInformationalVersionAttribute), False)
					If attributes Is Nothing Then
						Return Nothing
					End If
					If attributes.Length < 1 Then
						Return Nothing
					End If
					assemblyVersion_Conflict = New Version(DirectCast(attributes(0), AssemblyInformationalVersionAttribute).InformationalVersion)
				End If 'if
				Return assemblyVersion_Conflict
			End Get 'get AssemblyVersion
		End Property 'AssemblyVersion

		Private ReadOnly Property TheAssembly() As System.Reflection.Assembly
			Get
				If assembly Is Nothing Then
					assembly = System.Reflection.Assembly.GetEntryAssembly()
				End If
				Return assembly
			End Get 'get TheAssembly
		End Property 'TheAssembly

		Friend Shared Shadows ReadOnly Property Current() As AnamorphicDrawingApplication
			Get
				Return CType(Application.Current, AnamorphicDrawingApplication)
			End Get
		End Property

		Private startupComplete As Boolean
		Private assembly As System.Reflection.Assembly
'INSTANT VB NOTE: The field productName was renamed since Visual Basic does not allow fields to have the same name as other class members:
'INSTANT VB NOTE: The field copyright was renamed since Visual Basic does not allow fields to have the same name as other class members:
		Private productName_Conflict, copyright_Conflict As String
'INSTANT VB NOTE: The field assemblyVersion was renamed since Visual Basic does not allow fields to have the same name as other class members:
		Private assemblyVersion_Conflict As Version

	End Class 'class AnamorphicDrawingApplication

End Namespace 'namespace AnamorphicDrawing.Main
