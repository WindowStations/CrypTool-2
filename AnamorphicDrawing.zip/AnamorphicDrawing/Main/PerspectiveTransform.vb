﻿Imports System.Windows.Media.Imaging
Imports System.Windows
Imports System

' Anamorphic Drawing
'
' Copyright (c) Sergey A Kryukov, 2017, 2019
'
' http://www.SAKryukov.org
' http://www.codeproject.com/Members/SAKryukov
' https://github.com/SAKryukov
'
' Original publication:
' https://www.codeproject.com/Articles/1278552/Anamorphic-Drawing-for-the-Cheaters

Namespace AnamorphicDrawing.Main

	Friend Class PerspectiveTransform

		Friend Sub New(ByVal horizontalScaleFrom As Double, ByVal horizontalScaleTo As Double)
			Me.horizontalScaleFrom_Conflict = horizontalScaleFrom
			Me.horizontalScaleTo_Conflict = horizontalScaleTo
			Me.maxHorizontalScale = Math.Max(horizontalScaleFrom, horizontalScaleTo)
		End Sub 'PerspectiveTransform

		Friend Function Apply(ByVal source As BitmapSource) As BitmapSource
			Dim destinationWidth As Integer = CInt(Math.Truncate(Math.Round(maxHorizontalScale * source.PixelWidth)))
			Dim destination As New WriteableBitmap(destinationWidth, source.PixelHeight, source.DpiX, source.DpiY, source.Format, source.Palette)
			Dim bytesPerPixel As Integer = destination.BackBufferStride \ destinationWidth
			Dim sourceStride As Integer = bytesPerPixel * source.PixelWidth
			Dim destinationStride As Integer = bytesPerPixel * destinationWidth
			Dim sourceArray(sourceStride - 1) As Byte
			Dim destinationArray(destinationStride - 1) As Byte
			Dim fillByte As Byte = If(source.Format.Masks.Count = 4, CByte(0), CByte(&Hff))
			Dim factor As Double = (horizontalScaleTo_Conflict - horizontalScaleFrom_Conflict) / source.PixelHeight ' compression(y) = compressionFrom + factor * y
			If UseInterpolation = Interpolation.Linear Then
				LinearInterpolation(factor, bytesPerPixel, source, destination, destinationWidth, sourceArray, destinationArray, sourceStride, destinationStride, fillByte)
			Else
				NearestNeighborInterpolation(factor, bytesPerPixel, source, destination, destinationWidth, sourceArray, destinationArray, sourceStride, destinationStride, fillByte)
			End If
			Return destination
		End Function 'Apply

		Private Sub NearestNeighborInterpolation(ByVal factor As Double, ByVal bytesPerPixel As Integer, ByVal source As BitmapSource, ByVal destination As WriteableBitmap, ByVal destinationWidth As Integer, ByVal sourceArray() As Byte, ByVal destinationArray() As Byte, ByVal sourceStride As Integer, ByVal destinationStride As Integer, ByVal fillByte As Byte)
			Dim y As Integer = 0
			Do While y < destination.PixelHeight - 1
				Dim compression As Double = horizontalScaleFrom_Conflict + factor * y
				source.CopyPixels(New Int32Rect(0, y, source.PixelWidth, 1), sourceArray, sourceStride, 0)
				For х As Integer = 0 To destinationWidth - 1
					Dim shift As Double = (source.PixelWidth * compression - destinationWidth) / 2R
					Dim xSrc As Double = (х + shift) / compression
					Dim xSrcAddress As Integer = CInt(Math.Truncate(Math.Round(xSrc)))
					For byteIndex As Byte = 0 To CByte(bytesPerPixel - 1)
						If xSrcAddress >= 0 AndAlso xSrcAddress < source.PixelWidth Then
							destinationArray(х * bytesPerPixel + byteIndex) = sourceArray(xSrcAddress * bytesPerPixel + byteIndex)
						Else
							destinationArray(х * bytesPerPixel + byteIndex) = fillByte
						End If
					Next byteIndex
				Next х 'loop x
				destination.WritePixels(New Int32Rect(0, y, destinationWidth, 1), destinationArray, destinationStride, 0)
				y += 1
			Loop 'loop y
		End Sub 'NearestNeighborInterpolation

		Private Sub LinearInterpolation(ByVal factor As Double, ByVal bytesPerPixel As Integer, ByVal source As BitmapSource, ByVal destination As WriteableBitmap, ByVal destinationWidth As Integer, ByVal sourceArray() As Byte, ByVal destinationArray() As Byte, ByVal sourceStride As Integer, ByVal destinationStride As Integer, ByVal fillByte As Byte)
			Dim y As Integer = 0
			Do While y < destination.PixelHeight - 1
				Dim compression As Double = horizontalScaleFrom_Conflict + factor * y
				Dim sourcePixelWidthMinusOne As Integer = source.PixelWidth
				source.CopyPixels(New Int32Rect(0, y, source.PixelWidth, 1), sourceArray, sourceStride, 0)
				For х As Integer = 0 To destinationWidth - 1
					Dim shift As Double = (source.PixelWidth * compression - destinationWidth) / 2R
					Dim xSrc As Double = (х + shift) / compression
					Dim xSrcCurrent As Integer = CInt(Math.Truncate(xSrc))
					Dim xSrcNext As Integer = If(xSrcCurrent = sourcePixelWidthMinusOne, xSrcCurrent, xSrcCurrent + 1)
					Dim deltaX As Double = xSrc - xSrcCurrent
					For byteIndex As Byte = 0 To CByte(bytesPerPixel - 1)
						If xSrcCurrent >= 0 AndAlso xSrcNext < source.PixelWidth Then
							If xSrcCurrent <> xSrcNext Then
								Dim y1 As Double = sourceArray(xSrcCurrent * bytesPerPixel + byteIndex)
								Dim y2 As Double = sourceArray(xSrcNext * bytesPerPixel + byteIndex)
								destinationArray(х * bytesPerPixel + byteIndex) = CByte(Math.Truncate(y1 + (y2 - y1) * deltaX))
							Else
								destinationArray(х * bytesPerPixel + byteIndex) = sourceArray(xSrcCurrent * bytesPerPixel + byteIndex)
							End If
						Else
							destinationArray(х * bytesPerPixel + byteIndex) = fillByte
						End If
					Next byteIndex
				Next х 'loop x
				destination.WritePixels(New Int32Rect(0, y, destinationWidth, 1), destinationArray, destinationStride, 0)
				y += 1
			Loop 'loop y
		End Sub 'LinearInterpolation

		Friend ReadOnly Property HorizontalScaleFrom() As Double
			Get
				Return horizontalScaleFrom_Conflict
			End Get
		End Property
		Friend ReadOnly Property HorizontalScaleTo() As Double
			Get
				Return horizontalScaleTo_Conflict
			End Get
		End Property
		Friend Enum Interpolation
			Linear
			NearestNeighbor
		End Enum
		Friend Property UseInterpolation() As Interpolation

'INSTANT VB NOTE: The field horizontalScaleFrom was renamed since Visual Basic does not allow fields to have the same name as other class members:
'INSTANT VB NOTE: The field horizontalScaleTo was renamed since Visual Basic does not allow fields to have the same name as other class members:
		Private horizontalScaleFrom_Conflict, horizontalScaleTo_Conflict, maxHorizontalScale As Double

	End Class 'class PerspectiveTransform

End Namespace 'namespace AnamorphicDrawing.Main
