﻿Imports ResizeGrip = System.Windows.Controls.Primitives.ResizeGrip
Imports System.Windows.Input
Imports System.Windows.Controls
Imports System.Windows
Imports System

' Anamorphic Drawing
'
' Copyright (c) Sergey A Kryukov, 2017, 2019
'
' http://www.SAKryukov.org
' http://www.codeproject.com/Members/SAKryukov
' https://github.com/SAKryukov
'
' Original publication:
' https://www.codeproject.com/Articles/1278552/Anamorphic-Drawing-for-the-Cheaters

Namespace AnamorphicDrawing.Ui

	Friend MustInherit Class BaseGrip
		Inherits System.Windows.Controls.Primitives.ResizeGrip

		Friend Enum MoveSource
			KeyPress
			Drag
		End Enum
		Friend Class MotionEventArgs
			Inherits System.EventArgs

			Friend Sub New(ByVal source As MoveSource, ByVal index As Integer, ByVal position As Point)
				Me.Source = source
				Me.Index = index
				Me.Position = position
			End Sub
			Private privateSource As MoveSource
			Friend Property Source() As MoveSource
				Get
					Return privateSource
				End Get
				Private Set(ByVal value As MoveSource)
					privateSource = value
				End Set
			End Property
			Private privateIndex As Integer
			Friend Property Index() As Integer
				Get
					Return privateIndex
				End Get
				Private Set(ByVal value As Integer)
					privateIndex = value
				End Set
			End Property
			Private privatePosition As Point
			Friend Property Position() As Point
				Get
					Return privatePosition
				End Get
				Private Set(ByVal value As Point)
					privatePosition = value
				End Set
			End Property
		End Class 'MotionEventArgs

		Protected Overrides Sub OnPreviewMouseUp(ByVal e As MouseButtonEventArgs)
			ReleaseMouseCapture()
		End Sub

		Protected Overridable Function IsGoodMotionKey(ByVal e As KeyEventArgs) As Boolean
			If e.Key = Key.System Then
				Return e.SystemKey = Key.Up OrElse e.SystemKey = Key.Down OrElse e.SystemKey = Key.Left OrElse e.SystemKey = Key.Right
			Else
				Return e.Key = Key.Up OrElse e.Key = Key.Down OrElse e.Key = Key.Left OrElse e.Key = Key.Right
			End If 'if
		End Function 'IsGoodMotionKey

		Protected Overrides Sub OnPreviewKeyDown(ByVal e As KeyEventArgs)
			If Not (IsGoodMotionKey(e)) Then
				Return
			End If
			Dim key As Key = e.Key
			If e.Key = System.Windows.Input.Key.System Then
				key = e.SystemKey
			End If
			Dim speed = 1
			If Keyboard.IsKeyDown(System.Windows.Input.Key.LeftCtrl) OrElse Keyboard.IsKeyDown(System.Windows.Input.Key.LeftCtrl) Then
				speed *= 5
			End If
			If Keyboard.IsKeyDown(System.Windows.Input.Key.LeftShift) OrElse Keyboard.IsKeyDown(System.Windows.Input.Key.RightShift) Then
				speed *= 5
			End If
			If Keyboard.IsKeyDown(System.Windows.Input.Key.LeftAlt) OrElse Keyboard.IsKeyDown(System.Windows.Input.Key.RightAlt) Then
				speed *= 10
			End If
			Dim position As New Point(0, 0)
			If key = System.Windows.Input.Key.Up Then
				position = New Point(0, -speed)
			ElseIf key = System.Windows.Input.Key.Down Then
				position = New Point(0, +speed)
			ElseIf key = System.Windows.Input.Key.Left Then
				position = New Point(-speed, 0)
			ElseIf key = System.Windows.Input.Key.Right Then
				position = New Point(+speed, 0)
			End If
			RaiseEvent Moved(Me, New MotionEventArgs(MoveSource.KeyPress, Me.Index, position))
			e.Handled = e.Key <> System.Windows.Input.Key.System
		End Sub 'OnPreviewKeyDown

		Protected Overrides Sub OnPreviewMouseDown(ByVal e As MouseButtonEventArgs)
			Focus()
			Dim position = e.GetPosition(CType(Me.Parent, Canvas))
			RaiseEvent DragStarted(Me, New MotionEventArgs(MoveSource.Drag, Me.Index, position))
			CaptureMouse()
		End Sub 'OnPreviewMouseDown
		Protected Overrides Sub OnPreviewMouseMove(ByVal e As MouseEventArgs)
			If Not Me.IsMouseCaptured Then
				Return
			End If
			Dim position = e.GetPosition(CType(Me.Parent, Canvas))
			RaiseEvent Moved(Me, New MotionEventArgs(MoveSource.Drag, Me.Index, position))
		End Sub 'OnPreviewMouseMove

		Protected locatiobAtDragStart, mouseLocationAtDragStart As Point
		Friend Sub DragStartHandler(ByVal e As MotionEventArgs)
			locatiobAtDragStart = Me.Location
			mouseLocationAtDragStart = e.Position
		End Sub 'DragStartHandler

		Friend Property Location() As Point
			Get
				Return New Point(Canvas.GetLeft(Me) + Me.Width / 2, Canvas.GetTop(Me) + Me.Height / 2)
			End Get
			Set(ByVal value As Point)
				Canvas.SetLeft(Me, value.X - Me.Width / 2)
				Canvas.SetTop(Me, value.Y - Me.Height / 2)
				RaiseEvent LocationChanged(Me, New EventArgs())
			End Set 'set Location
		End Property 'Location

		Friend Property Index() As Integer

		Friend Event LocationChanged As EventHandler
		Friend Event Moved As System.EventHandler(Of MotionEventArgs)
		Friend Event DragStarted As System.EventHandler(Of MotionEventArgs)

	End Class 'BaseGrip

End Namespace 'namespace AnamorphicDrawing.Ui
