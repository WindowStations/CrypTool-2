﻿Imports System.Windows.Input
Imports System.Windows.Controls
Imports System.Windows

' Anamorphic Drawing
'
' Copyright (c) Sergey A Kryukov, 2017, 2019
'
' http://www.SAKryukov.org
' http://www.codeproject.com/Members/SAKryukov
' https://github.com/SAKryukov
'
' Original publication:
' https://www.codeproject.com/Articles/1278552/Anamorphic-Drawing-for-the-Cheaters

Namespace AnamorphicDrawing.Ui

	Partial Friend Class CropGrip
		Inherits BaseGrip

		Protected Overrides Sub OnMouseDown(ByVal e As System.Windows.Input.MouseButtonEventArgs)
			Focus()
		End Sub 'OnMouseDown

		Protected Overrides Function IsGoodMotionKey(ByVal e As KeyEventArgs) As Boolean
			If Me.Direction = GripDirection.Horizontal Then
				If e.Key = Key.System Then
					Return e.SystemKey = Key.Left OrElse e.SystemKey = Key.Right
				Else
					Return e.Key = Key.Down OrElse e.Key = Key.Left OrElse e.Key = Key.Right
				End If ' if System
			Else
				If e.Key = Key.System Then
					Return e.SystemKey = Key.Up OrElse e.SystemKey = Key.Down
				Else
					Return e.Key = Key.Up OrElse e.Key = Key.Down
				End If ' if System
			End If 'if Direction
		End Function 'IsGoodMotionKey

	End Class 'CropGrip

End Namespace 'namespace AnamorphicDrawing.Ui
