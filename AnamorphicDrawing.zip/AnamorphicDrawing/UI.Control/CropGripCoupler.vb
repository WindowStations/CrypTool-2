﻿Imports System.Windows.Controls
Imports System.Windows

' Anamorphic Drawing
'
' Copyright (c) Sergey A Kryukov, 2017, 2019
'
' http://www.SAKryukov.org
' http://www.codeproject.com/Members/SAKryukov
' https://github.com/SAKryukov
'
' Original publication:
' https://www.codeproject.com/Articles/1278552/Anamorphic-Drawing-for-the-Cheaters

Namespace AnamorphicDrawing.Ui

	Friend Class CropGripCoupler

		Friend Sub New(ByVal image As Image, ByVal cropGripSet() As CropGrip, ByVal cropBorder As Border, ByVal frameThickness As Double)
			Dim cropBorderThicknessAtDragStart As Thickness = CType(Nothing, Thickness)
			Dim mouseAtDragStart As Point = CType(Nothing, Point)
			For index As Integer = 0 To cropGripSet.Length - 1
				Dim grip As CropGrip = cropGripSet(index)
				grip.Index = index
				AddHandler grip.Moved, Sub(sender, eventArgs)
					Dim aGrip As CropGrip = cropGripSet(eventArgs.Index)
					Dim position As Double
					Dim newThickness As Double = Double.NaN
					If eventArgs.Source = BaseGrip.MoveSource.Drag Then
						If aGrip.Direction = CropGrip.GripDirection.Horizontal Then
							position = eventArgs.Position.X - mouseAtDragStart.X
							If aGrip.IsHighValueRole Then
								newThickness = cropBorderThicknessAtDragStart.Right - position
							Else
								newThickness = cropBorderThicknessAtDragStart.Left + position
							End If
						Else
							position = eventArgs.Position.Y - mouseAtDragStart.Y
							If aGrip.IsHighValueRole Then
								newThickness = cropBorderThicknessAtDragStart.Bottom - position
							Else
								newThickness = cropBorderThicknessAtDragStart.Top + position
							End If
						End If 'if Direction
					Else
						If aGrip.Direction = CropGrip.GripDirection.Horizontal Then
							position = eventArgs.Position.X
						Else
							position = eventArgs.Position.Y
						End If
					End If 'if
					MoveCropBorder(aGrip, position, newThickness)
				End Sub 'grip.Moved
				AddHandler grip.DragStarted, Sub(sender, eventArgs)
					mouseAtDragStart = eventArgs.Position
					cropBorderThicknessAtDragStart = cropBorder.BorderThickness
				End Sub 'grip.DragStarted
			Next index 'loop
			Me.image = image
			Me.cropGripSet = cropGripSet
			Me.cropBorder = cropBorder
			Me.canvas = CType(image.Parent, Canvas)
			Me.frameThickness = frameThickness
		End Sub 'CropGripCoupler

		Private Sub MoveCropBorder(ByVal grip As CropGrip, ByVal position As Double, ByVal newThickness As Double)
			Dim minSize As Double = frameThickness
			Dim delta As Double = position
			Dim left As Double = cropBorder.BorderThickness.Left
			Dim right As Double = cropBorder.BorderThickness.Right
			Dim top As Double = cropBorder.BorderThickness.Top
			Dim bottom As Double = cropBorder.BorderThickness.Bottom
			Dim minLeft As Double = cropBorderMinimalThickness.Left
			Dim minRight As Double = cropBorderMinimalThickness.Right
			Dim minTop As Double = cropBorderMinimalThickness.Top
			Dim minBottom As Double = cropBorderMinimalThickness.Bottom
			If grip.Direction = CropGrip.GripDirection.Horizontal Then
				If grip.IsHighValueRole Then
					If Double.IsNaN(newThickness) Then
						right -= delta
					Else
						right = newThickness
					End If
					If right < minRight Then
						right = minRight
					End If
					Dim newWidth As Double = cropBorder.ActualWidth - left - right
					If newWidth < minSize Then
						right = cropBorder.ActualWidth - left - minSize
					End If
				Else
					If Double.IsNaN(newThickness) Then
						left += delta
					Else
						left = newThickness
					End If
					If left < minLeft Then
						left = minLeft
					End If
					Dim newWidth As Double = cropBorder.ActualWidth - left - right
					If newWidth < minSize Then
						left = cropBorder.ActualWidth - right - minSize
					End If
				End If 'if high
			Else
				If grip.IsHighValueRole Then
					If Double.IsNaN(newThickness) Then
						bottom -= delta
					Else
						bottom = newThickness
					End If
					If bottom < minBottom Then
						bottom = minBottom
					End If
					Dim newHeight As Double = cropBorder.ActualHeight - top - bottom
					If newHeight < minSize Then
						bottom = cropBorder.ActualHeight - top - minSize
					End If
				Else
					If Double.IsNaN(newThickness) Then
						top += delta
					Else
						top = newThickness
					End If
					If top < minTop Then
						top = minTop
					End If
					Dim newHeight As Double = cropBorder.ActualHeight - top - bottom
					If newHeight < minSize Then
						top = cropBorder.ActualHeight - bottom - minSize
					End If
				End If 'if hight
			End If
			cropBorder.BorderThickness = New Thickness(left, top, right, bottom)
			FollowCropBorder()
		End Sub 'MoveCropBorder

		Private cropBorderMinimalThickness As Thickness = CType(Nothing, Thickness)
		Friend Sub Arrange()
			System.Windows.Controls.Canvas.SetTop(cropBorder, -Me.frameThickness)
			System.Windows.Controls.Canvas.SetLeft(cropBorder, -Me.frameThickness)
			cropBorder.Width = canvas.ActualWidth + Me.frameThickness * 2
			cropBorder.Height = canvas.ActualHeight + Me.frameThickness * 2
			Dim deltaX As Double = Me.frameThickness + (canvas.ActualWidth - image.Width) / 2
			Dim deltaY As Double = Me.frameThickness + (canvas.ActualHeight - image.Height) / 2
			If deltaX < 0 Then
				deltaX = 0
			End If
			If deltaY < 0 Then
				deltaY = 0
			End If
			cropBorder.BorderThickness = New Thickness(deltaX, deltaY, deltaX, deltaY)
			cropBorderMinimalThickness = cropBorder.BorderThickness
			FollowCropBorder()
		End Sub 'Arrange

		Private Sub FollowCropBorder()
			For Each grip As CropGrip In cropGripSet
				If grip.Direction = CropGrip.GripDirection.Horizontal Then
					If grip.IsHighValueRole Then
						System.Windows.Controls.Canvas.SetLeft(grip, canvas.ActualWidth - cropBorder.BorderThickness.Right + grip.ActualWidth)
					Else
						System.Windows.Controls.Canvas.SetLeft(grip, cropBorder.BorderThickness.Left - 2 * grip.ActualWidth)
					End If
					System.Windows.Controls.Canvas.SetTop(grip, cropBorder.BorderThickness.Top - 2 * grip.ActualWidth)
					Dim height = canvas.ActualHeight - cropBorder.BorderThickness.Top - cropBorder.BorderThickness.Bottom + 4 * grip.ActualWidth
					If height < 0 Then
						height = 0
					End If
					grip.Height = height
				Else
					If grip.IsHighValueRole Then
						System.Windows.Controls.Canvas.SetTop(grip, canvas.ActualHeight - cropBorder.BorderThickness.Bottom + grip.ActualHeight)
					Else
						System.Windows.Controls.Canvas.SetTop(grip, cropBorder.BorderThickness.Top - 2 * grip.ActualHeight)
					End If
					System.Windows.Controls.Canvas.SetLeft(grip, cropBorder.BorderThickness.Left - 2 * grip.ActualHeight)
					Dim width = canvas.ActualWidth - cropBorder.BorderThickness.Left - cropBorder.BorderThickness.Right + 4 * grip.ActualHeight
					If width < 0 Then
						width = 0
					End If
					grip.Width = width
				End If 'if
			Next grip 'loop
		End Sub 'FollowCropBorder

		Private image As Image
		Private cropGripSet() As CropGrip
		Private cropBorder As Border
		Private canvas As Canvas
		Private frameThickness As Double

	End Class 'class CropGripCoupler

End Namespace 'namespace AnamorphicDrawing.Ui
