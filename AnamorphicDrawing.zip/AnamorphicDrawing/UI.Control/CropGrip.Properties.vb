﻿Imports System.Windows
Imports System

' Anamorphic Drawing
'
' Copyright (c) Sergey A Kryukov, 2017, 2019
'
' http://www.SAKryukov.org
' http://www.codeproject.com/Members/SAKryukov
' https://github.com/SAKryukov
'
' Original publication:
' https://www.codeproject.com/Articles/1278552/Anamorphic-Drawing-for-the-Cheaters

Namespace AnamorphicDrawing.Ui

	Partial Friend Class CropGrip
		Inherits BaseGrip

		Private Enum GripRoleValue As Byte
			HighValueMask = &Hf
			OrientationMask = &Hf0
			HighValue = 1
			Vertical = &H10
			Horizontal = &H20
		End Enum 'GripRoleValue

		Friend Enum GripRole As Byte
			Left = GripRoleValue.Horizontal
			Right = GripRoleValue.Horizontal Or GripRoleValue.HighValue
			Top = GripRoleValue.Vertical
			Bottom = GripRoleValue.Vertical Or GripRoleValue.HighValue
		End Enum 'enum GripRole

		Friend Enum GripDirection As Byte
			Horizontal = GripRoleValue.Horizontal
			Vertical = GripRoleValue.Vertical
		End Enum

		Private Shared RolePropertyMetadata As New FrameworkPropertyMetadata()

		Private Shared RoleProperty As DependencyProperty = DependencyProperty.Register("Role", GetType(GripRole), GetType(CropGrip), RolePropertyMetadata)

		Friend Property Role() As GripRole
			Get
				Return DirectCast(GetValue(RoleProperty), GripRole)
			End Get
			Set(ByVal value As GripRole)
				SetValue(RoleProperty, value)
			End Set
		End Property 'Role

		Friend ReadOnly Property IsHighValueRole() As Boolean
			Get
				Return (CByte(Role) And CByte(GripRoleValue.HighValueMask)) > 0
			End Get
		End Property
		Friend ReadOnly Property Direction() As GripDirection
			Get
				Return CType(CByte(Role) And CByte(GripRoleValue.OrientationMask), GripDirection)
			End Get
		End Property

	End Class 'CropGrip

End Namespace 'namespace AnamorphicDrawing.Ui
