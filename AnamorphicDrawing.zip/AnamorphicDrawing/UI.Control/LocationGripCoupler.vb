﻿Imports System.Windows.Shapes
Imports System.Windows.Controls
Imports System.Windows
Imports System

' Anamorphic Drawing
'
' Copyright (c) Sergey A Kryukov, 2017, 2019
'
' http://www.SAKryukov.org
' http://www.codeproject.com/Members/SAKryukov
' https://github.com/SAKryukov
'
' Original publication:
' https://www.codeproject.com/Articles/1278552/Anamorphic-Drawing-for-the-Cheaters

Namespace AnamorphicDrawing.Ui

	Friend Class LocationGripCoupler

		Friend Sub New(ByVal image As Image, ByVal gripSet() As LocationGrip, ByVal pad As Polyline, ByVal mark As Polyline)
			Me.gripSet = gripSet
			Me.pad = pad
			Me.mark = mark
			canvas = CType(mark.Parent, Canvas)
			For index As Integer = 0 To gripSet.Length
				pad.Points.Add(New Point())
				mark.Points.Add(New Point())
			Next index 'loop
			For index As Integer = 0 To gripSet.Length - 1
				Dim instance As LocationGrip = gripSet(index)
				instance.Index = index
				AddHandler instance.OnSelectedExclusively, Sub(sender, eventArgs)
					For Each anotherInstance As LocationGrip In gripSet
						If anotherInstance IsNot instance Then
							anotherInstance.IsSelected = False
						End If
					Next anotherInstance
				End Sub 'instance.OnSelectedExclusively
				AddHandler instance.Moved, Sub(sender, eventArgs)
					For gripIndex As Integer = 0 To gripSet.Length - 1
						Dim grip As LocationGrip = gripSet(gripIndex)
						If Not grip.IsSelected Then
							Continue For
						End If
						grip.MotionHandler(eventArgs)
						Dim newLocation As Point = grip.Location
						FollowGrip(gripIndex)
					Next gripIndex 'loop
					AdjustLastSegment()
				End Sub 'instance.Moved
				AddHandler instance.DragStarted, Sub(sender, eventArgs)
					For Each grip As LocationGrip In gripSet
						If grip.IsSelected Then
							grip.DragStartHandler(eventArgs)
						End If
					Next grip
				End Sub 'instance.DragStarted
			Next index 'loop
			AddHandler image.MouseDown, Sub(sender, eventArgs)
				Dim point = eventArgs.GetPosition(canvas)
				Dim focused As Integer = Array.FindIndex(Of LocationGrip)(Me.gripSet, Function(aGrip) aGrip.IsFocused)
				If focused < 0 Then
					Return
				End If
				gripSet(focused).Location = point
				FollowGrip()
				focused += 1
				Dim [next] As Integer = focused
				If [next] >= gripSet.Length Then
					[next] = 0
				End If
				gripSet([next]).Focus()
			End Sub 'image.MouseDown
		End Sub 'LocationGripCoupler

		Private Sub AdjustLastSegment()
			mark.Points(mark.Points.Count - 1) = pad.Points(0)
			pad.Points(mark.Points.Count - 1) = pad.Points(0)
		End Sub 'AdjustLastSegment
		Private Sub FollowGrip(ByVal index As Integer)
			Dim location As Point = gripSet(index).Location
			mark.Points(index) = location
			pad.Points(index) = location
		End Sub 'FollowGrip
		Private Sub FollowGrip()
			For index As Integer = 0 To gripSet.Length - 1
				FollowGrip(index)
			Next index
			AdjustLastSegment()
		End Sub 'FollowGrip

		Friend Sub Arrange(ByVal origin As Point, ByVal size As Size)
			gripSet(0).Location = origin
			gripSet(1).Location = New Point(size.Width - origin.X, origin.Y)
			gripSet(2).Location = New Point(size.Width - origin.X, size.Height - origin.Y)
			gripSet(3).Location = New Point(origin.X, size.Height - origin.Y)
			FollowGrip()
		End Sub 'Arrange

		Private gripSet() As LocationGrip
		Private pad, mark As Polyline
		Private canvas As Canvas

	End Class 'class LocationGripCoupler

End Namespace 'namespace AnamorphicDrawing.Ui
