﻿Imports System.Windows.Media.Imaging
Imports System.Windows.Controls
Imports System.Windows
Imports System

' Anamorphic Drawing
'
' Copyright (c) Sergey A Kryukov, 2017, 2019
'
' http://www.SAKryukov.org
' http://www.codeproject.com/Members/SAKryukov
' https://github.com/SAKryukov
'
' Original publication:
' https://www.codeproject.com/Articles/1278552/Anamorphic-Drawing-for-the-Cheaters

Namespace AnamorphicDrawing.Ui

	Friend Class Collaboration
		Private bitmap As BitmapSource

		Friend Interface ICollaborationProvider
			ReadOnly Property Collaboration() As Collaboration
		End Interface 'interface ICollaborationProvider

		Friend Sub New(ByVal control As Control, ByVal canvas As Canvas, ByVal image As Image, ByVal canGoNext As Func(Of Boolean), ByVal transform As Func(Of BitmapSource))
			Me.control = control
			Me.canvas = canvas
			Me.image = image
			Me.canGoNext = canGoNext
			Me.transform_Conflict = transform
		End Sub 'Collaboration

		Friend Property BitmapSource() As BitmapSource
			Get
				Return bitmap
			End Get
			Set(ByVal value As BitmapSource)
				If bitmap Is value Then
					Return
				End If
				bitmap = value
				image.Source = bitmap
				Main.ImageProcessingUtility.ArrangeImage(bitmap, image, canvas)
			End Set 'get Bitmap
		End Property 'Bitmap

		Friend Function Transform() As BitmapSource
			If transform_Conflict Is Nothing OrElse BitmapSource Is Nothing Then
				Return Nothing
			Else
				Return transform_Conflict()
			End If
		End Function 'Transform

		Friend Property Visibility() As Visibility
			Get
				Return control.Visibility
			End Get
			Set(ByVal value As Visibility)
				'If VisibilityChanging IsNot Nothing Then
				'	VisibilityChanging.Invoke(Me, New EventArgs())
				'End If
				RaiseEvent VisibilityChanging(Me, Nothing)
				control.Visibility = value
				RaiseEvent VisibilityChanged(Me, New EventArgs())
				If value = System.Windows.Visibility.Visible Then
					InvokeStatusChanged(Me.control, New StatusChangeEventArgs(StatusChangeAspect.SelectonChange Or StatusChangeAspect.StatusLineMessageChange, shadowSelectionInfo, shadowStatusLineMessage))
				End If
			End Set 'set Visibility
		End Property 'Visibility

		Friend ReadOnly Property IsReadyForNext() As Boolean
			Get
				If BitmapSource Is Nothing Then
					Return False
				End If
				If canGoNext IsNot Nothing Then
					Return canGoNext()
				Else
					Return True
				End If
			End Get 'get IsReadyForNext
		End Property 'IsReadyForNext

		Friend Enum StatusChangeAspect
			NextEnabledChange = 1
			SelectonChange = 2
			StatusLineMessageChange = 4
		End Enum
		Friend Class StatusChangeEventArgs
			Inherits EventArgs

			Friend Sub New(ByVal aspect As StatusChangeAspect, ByVal selectionInfo As String, ByVal statusLineMessage As String)
				Me.Aspect = aspect
				Me.SelectionInfo = selectionInfo
				Me.StatusMessage = statusLineMessage
			End Sub 'StatusChangeEventArgs
			Private privateAspect As StatusChangeAspect
			Friend Property Aspect() As StatusChangeAspect
				Get
					Return privateAspect
				End Get
				Private Set(ByVal value As StatusChangeAspect)
					privateAspect = value
				End Set
			End Property
			Private privateSelectionInfo As String
			Friend Property SelectionInfo() As String
				Get
					Return privateSelectionInfo
				End Get
				Private Set(ByVal value As String)
					privateSelectionInfo = value
				End Set
			End Property
			Private privateStatusMessage As String
			Friend Property StatusMessage() As String
				Get
					Return privateStatusMessage
				End Get
				Private Set(ByVal value As String)
					privateStatusMessage = value
				End Set
			End Property
		End Class 'StatusChangeEventArgs

		Private shadowSelectionInfo As String = String.Empty
		Private shadowStatusLineMessage As String = String.Empty

		Friend Sub InvokeStatusChanged(ByVal sender As Control, ByVal eventArgs As StatusChangeEventArgs) ' for *Step controls
			If (eventArgs.Aspect And Collaboration.StatusChangeAspect.SelectonChange) > 0 AndAlso eventArgs.SelectionInfo IsNot Nothing Then
				shadowSelectionInfo = eventArgs.SelectionInfo
			End If
			If (eventArgs.Aspect And Collaboration.StatusChangeAspect.StatusLineMessageChange) > 0 AndAlso eventArgs.StatusMessage IsNot Nothing Then
				shadowStatusLineMessage = eventArgs.StatusMessage
			End If
			RaiseEvent StatusChanged(sender, eventArgs)
		End Sub 'InvokeStatusChanged

		Friend ReadOnly Property WizardStep() As String
			Get
				If control Is Nothing Then
					Return String.Empty
				End If
				If control.DataContext Is Nothing Then
					Return String.Empty
				End If
				Return DirectCast(control.DataContext, String)
			End Get 'get WizardStep
		End Property 'WizardStep

		Friend Event StatusChanged As EventHandler(Of StatusChangeEventArgs) ' for MainWindow
		Friend Event VisibilityChanging As EventHandler(Of EventArgs) '(Of visibilitychangedargs)
		Friend Event VisibilityChanged As EventHandler(Of EventArgs)

		Private control As Control
		Private canvas As Canvas
		Private image As Image
'INSTANT VB NOTE: The field transform was renamed since Visual Basic does not allow fields to have the same name as other class members:
		Private transform_Conflict As Func(Of BitmapSource)
		Private canGoNext As Func(Of Boolean)

	End Class 'class Collaboration

End Namespace 'namespace AnamorphicDrawing.Ui
