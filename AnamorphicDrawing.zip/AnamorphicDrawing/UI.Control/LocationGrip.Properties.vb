﻿Imports System.Windows

' Anamorphic Drawing
'
' Copyright (c) Sergey A Kryukov, 2017, 2019
'
' http://www.SAKryukov.org
' http://www.codeproject.com/Members/SAKryukov
' https://github.com/SAKryukov
'
' Original publication:
' https://www.codeproject.com/Articles/1278552/Anamorphic-Drawing-for-the-Cheaters

Namespace AnamorphicDrawing.Ui

	Partial Friend Class LocationGrip
		Inherits BaseGrip

		Private Shared SelectedPropertyMetadata As New FrameworkPropertyMetadata(False)

		Private Shared SelectedProperty As DependencyProperty = DependencyProperty.Register("IsSelected", GetType(Boolean), GetType(LocationGrip), SelectedPropertyMetadata)

		Public Property IsSelected() As Boolean
			Get
				Return DirectCast(GetValue(SelectedProperty), Boolean)
			End Get
			Set(ByVal value As Boolean)
				SetValue(SelectedProperty, value)
			End Set
		End Property 'IsSelected

	End Class 'class LocationGrip

End Namespace 'namespace AnamorphicDrawing.Ui
