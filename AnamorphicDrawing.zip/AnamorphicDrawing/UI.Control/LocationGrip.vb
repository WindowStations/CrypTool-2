﻿Imports System.Windows.Input
Imports System.Windows.Controls
Imports System.Windows
Imports System

' Anamorphic Drawing
'
' Copyright (c) Sergey A Kryukov, 2017, 2019
'
' http://www.SAKryukov.org
' http://www.codeproject.com/Members/SAKryukov
' https://github.com/SAKryukov
'
' Original publication:
' https://www.codeproject.com/Articles/1278552/Anamorphic-Drawing-for-the-Cheaters

Namespace AnamorphicDrawing.Ui

	Partial Friend Class LocationGrip
		Inherits BaseGrip

		Private Sub NotifyExclusiveSelection()
			If Not (Keyboard.IsKeyDown(Key.LeftShift) OrElse Keyboard.IsKeyDown(Key.RightShift)) Then
				RaiseEvent OnSelectedExclusively(Me, New EventArgs())
			End If
		End Sub 'NotifyExclusiveSelection

		Protected Overrides Sub OnGotFocus(ByVal e As RoutedEventArgs)
			IsSelected = True
			NotifyExclusiveSelection()
			MyBase.OnGotFocus(e)
		End Sub 'OnGotFocus

		Protected Overrides Sub OnPreviewMouseDoubleClick(ByVal e As MouseButtonEventArgs)
			NotifyExclusiveSelection()
		End Sub 'protected override void OnPreviewMouseDoubleClick(MouseButtonEventArgs e)

		Friend Sub MotionHandler(ByVal e As MotionEventArgs)
			Dim curbPoint As Func(Of FrameworkElement, Double, Double, Point) = Function(anElement, x, y)
				If x < 0 Then
					x = 0
				End If
				If y < 0 Then
					y = 0
				End If
				If x >= anElement.ActualWidth Then
					x = anElement.ActualWidth
				End If
				If y >= anElement.ActualHeight Then
					y = anElement.ActualHeight
				End If
				Return New Point(x, y)
			End Function 'curbPoint
			Dim canvas As Canvas = CType(Me.Parent, Canvas)
			If e.Source = MoveSource.Drag Then
				Dim x As Double = locatiobAtDragStart.X + e.Position.X - mouseLocationAtDragStart.X
				Dim y As Double = locatiobAtDragStart.Y + e.Position.Y - mouseLocationAtDragStart.Y
				Location = curbPoint(canvas, x, y)
			ElseIf e.Source = MoveSource.KeyPress Then
				Location = curbPoint(canvas, Location.X + e.Position.X, Location.Y + e.Position.Y)
			End If
		End Sub 'MotionHandler

		Friend Event OnSelectedExclusively As System.EventHandler

	End Class 'class LocationGrip

End Namespace 'namespace AnamorphicDrawing.Ui
